import Container from './styles/Container';
import Popup from './styles/Popup';
import Header from './styles/Header';
import Boxes from './styles/Boxes';
import Boxespermissions from './styles/Boxespermissions';
import Headerpermissions from './styles/Headerpermissions';
import Threatheader from './styles/Threatheader';
import Chart from './styles/Chart';


export default function App() {
  return (
    <>
      
      <Threatheader/>
      <Chart/>
    
    </>
   
  );
}

